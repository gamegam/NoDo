name Kart_Rush;

class Main{
}