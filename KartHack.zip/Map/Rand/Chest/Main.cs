useing user.Meloby.Unity;
useing user.Config;

class Main Unity{
    
    new Config = ["Speed", "Fly"];
}