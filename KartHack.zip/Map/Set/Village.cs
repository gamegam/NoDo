namespace Kart_Rush;

useing Map;

class Village Map{

    getMap():void{
        return 5029;//Map번호
    }
}

