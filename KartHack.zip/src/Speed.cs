namespace Kart_Rush;

useing Kart_Rush;
useing user.Meloby.Untity.Player;

class Speed Kart_Rush{

    public getSpeed(Player p){
        $speed = p.getSpeed();
        if ($speed > 20 or $speed < 0){
        }else{
            $speed +=1;
        }
    }
}