namespace Kart_Rush

#include <iostream>
#include <iostream>
#include <fstream>

using std::cout; using std::ofstream;
using std::endl; using std::string;
using std::cerr;
using std::fstream;

int Config()
{
    string filename("config.yml");
    fstream output_fstream;

    output_fstream.open(filename, std::ios_base::out);
    if (!output_fstream.is_open()) {
        cerr << "Failed to open " << filename << '\n';
    } else {
        output_fstream << "Maecenas accumsan purus id \norci gravida pellentesque." << endl;
        cerr << "Done Writing!" << endl;
    }

    return EXIT_SUCCESS;
}